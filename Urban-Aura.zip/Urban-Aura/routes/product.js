const express = require('express');
const router = express.Router();

const db = require('../db');
const authMiddleware = require('../middleware/auth');
// 1. ADD PRODUCT (ADMIN / TEST PURPOSE)
router.post('/add', authMiddleware, (req, res) => {
    const { name, price } = req.body;

    const sql = `
        INSERT INTO products (name, price)
        VALUES (?, ?)
    `;

    db.query(sql, [name, price], (err, result) => {
        if (err) {
            return res.status(500).json({
                message: "Error adding product",
                error: err
            });
        }

        res.json({
            message: "Product added successfully",
            product_id: result.insertId
        });
    });
});


// 2. GET ALL PRODUCTS
router.get('/', (req, res) => {
    const sql = `SELECT * FROM products`;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({
                message: "Error fetching products",
                error: err
            });
        }

        res.json({
            message: "Products fetched successfully",
            products: results
        });
    });
});


// 3. GET SINGLE PRODUCT
router.get('/:id', (req, res) => {
    const id = req.params.id;

    const sql = `SELECT * FROM products WHERE id = ?`;

    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({
                message: "Error fetching product",
                error: err
            });
        }

        res.json({
            message: "Product fetched successfully",
            product: result[0]
        });
    });
});

module.exports = router;