const express = require('express');
const router = express.Router();

const authMiddleware = require('../middleware/auth');
const db = require('../db');


// =======================
// PLACE ORDER
// =======================
router.post('/place', authMiddleware, (req, res) => {
    const user_id = req.user.id;

    // Get cart items with real product price
    const getCartSql = `
        SELECT 
            cart.product_id,
            cart.quantity,
            products.price
        FROM cart
        JOIN products ON cart.product_id = products.id
        WHERE cart.user_id = ?
    `;

    db.query(getCartSql, [user_id], (err, cartItems) => {
        if (err) {
            return res.status(500).json({
                message: "Error fetching cart",
                error: err
            });
        }

        if (cartItems.length === 0) {
            return res.json({ message: "Cart is empty" });
        }

        // Calculate total price
        let total = 0;

        cartItems.forEach(item => {
            total += item.quantity * item.price;
        });

        // Insert order
        const insertOrderSql = `
            INSERT INTO orders (user_id, total_amount, status)
            VALUES (?, ?, 'placed')
        `;

        db.query(insertOrderSql, [user_id, total], (err2, result) => {
            if (err2) {
                return res.status(500).json({
                    message: "Order failed",
                    error: err2
                });
            }

            // Clear cart after order
            const clearCartSql = `
                DELETE FROM cart WHERE user_id = ?
            `;

            db.query(clearCartSql, [user_id], () => {
                res.json({
                    message: "Order placed successfully",
                    order_id: result.insertId,
                    total_amount: total
                });
            });
        });
    });
});


// =======================
// ORDER HISTORY
// =======================
router.get('/my', authMiddleware, (req, res) => {
    const user_id = req.user.id;

    const sql = `
        SELECT * FROM orders
        WHERE user_id = ?
        ORDER BY created_at DESC
    `;

    db.query(sql, [user_id], (err, results) => {
        if (err) {
            return res.status(500).json({
                message: "Error fetching orders",
                error: err
            });
        }

        res.json({
            message: "Order history fetched successfully",
            orders: results
        });
    });
});


module.exports = router;