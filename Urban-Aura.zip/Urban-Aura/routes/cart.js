const express = require('express');
const router = express.Router();

const authMiddleware = require('../middleware/auth');
const db = require('../db');

// TEST PROTECTED ROUTE
router.get('/', authMiddleware, (req, res) => {
    res.json({
        message: "Cart route is working and protected",
        user: req.user
    });
});

// ADD TO CART
router.post('/add', authMiddleware, (req, res) => {
    const user_id = req.user.id;
    const { product_id, quantity } = req.body;

    const checkSql = `
        SELECT * FROM cart
        WHERE user_id = ? AND product_id = ?
    `;

    db.query(checkSql, [user_id, product_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                message: "Database error",
                error: err
            });
        }

        if (result.length > 0) {
            const newQty = result[0].quantity + (quantity || 1);

            const updateSql = `
                UPDATE cart
                SET quantity = ?
                WHERE user_id = ? AND product_id = ?
            `;

            db.query(
                updateSql,
                [newQty, user_id, product_id],
                (err2) => {
                    if (err2) {
                        return res.status(500).json({
                            message: "Update error",
                            error: err2
                        });
                    }

                    return res.json({
                        message:
                            "Cart updated (quantity increased)"
                    });
                }
            );
        } else {
            const insertSql = `
                INSERT INTO cart
                (user_id, product_id, quantity)
                VALUES (?, ?, ?)
            `;

            db.query(
                insertSql,
                [
                    user_id,
                    product_id,
                    quantity || 1
                ],
                (err3, result3) => {
                    if (err3) {
                        return res.status(500).json({
                            message: "Insert error",
                            error: err3
                        });
                    }

                    return res.json({
                        message:
                            "Product added to cart",
                        cart_id:
                            result3.insertId
                    });
                }
            );
        }
    });
});

// VIEW CART
router.get('/view', authMiddleware, (req, res) => {
    const user_id = req.user.id;

    const sql = `
        SELECT
            cart.id AS cart_id,
            cart.product_id,
            cart.quantity,
            cart.created_at,
            products.name,
            products.price,
            products.image
        FROM cart
        JOIN products
        ON cart.product_id = products.id
        WHERE cart.user_id = ?
    `;

    db.query(sql, [user_id], (err, results) => {
        if (err) {
            return res.status(500).json({
                message: "Database error",
                error: err
            });
        }

        res.json({
            message:
                "Cart fetched successfully",
            cart: results
        });
    });
});

// UPDATE CART QUANTITY
router.put('/update', authMiddleware, (req, res) => {
    const user_id = req.user.id;
    const { product_id, quantity } = req.body;

    const sql = `
        UPDATE cart
        SET quantity = ?
        WHERE user_id = ? AND product_id = ?
    `;

    db.query(
        sql,
        [quantity, user_id, product_id],
        (err) => {
            if (err) {
                return res.status(500).json({
                    message: "Update failed",
                    error: err
                });
            }

            res.json({
                message: "Quantity updated"
            });
        }
    );
});

// REMOVE ITEM FROM CART
router.delete(
    '/remove/:product_id',
    authMiddleware,
    (req, res) => {
        const user_id = req.user.id;
        const product_id =
            req.params.product_id;

        const sql = `
            DELETE FROM cart
            WHERE user_id = ?
            AND product_id = ?
        `;

        db.query(
            sql,
            [user_id, product_id],
            (err) => {
                if (err) {
                    return res.status(500).json({
                        message: "Delete failed",
                        error: err
                    });
                }

                res.json({
                    message: "Item removed"
                });
            }
        );
    }
);

module.exports = router;